<?php
$cantidad= $_POST["txt_cantidad"];
$tipo= $_POST["tipo"];
$opcion = $_POST["opcion"];
$chispas= $_POST["chispas"];

if($cantidad <=0)
{
    echo "ha digitado valor incorecto";
    exit;
}

if($tipo==1)
{
    $valor=6000;
    $total = $valor * $cantidad;
    // echo $total;


if($opcion==1)
   {
    $valor=1000 * $cantidad;
    $total = $valor+$total;
    // echo $total;
   }


   if($chispas==1)
   {
    $llevar=$cantidad * 2000;
    $total=$total+$llevar;
    // echo $total;

   }
}
    

if($tipo==2)
{
    $valor=10000;
    $total = $valor * $cantidad;
    // echo $total;


    if($opcion==1)
   {
    $valor=1000 * $cantidad;
    $total = $valor+$total;
    // echo $total;
   }


   if($chispas==1)
   {
    $llevar=$cantidad * 2000;
    $total=$total+$llevar;
    // echo $total;

   }
}

if($tipo==3)
{
    $valor=20000;
    $total = $valor * $cantidad;
    // echo $total;


    if($opcion==1)
   {
    $valor=1000 * $cantidad;
    $total = $valor+$total;
    // echo $total;
   }


   if($chispas==1)
   {
    $llevar=$cantidad * 2000;
    $total=$total+$llevar;
    // echo $total;

   }
}


echo "El Total Pagar es de:".$total;
?>